// Sample component
export default function SampleComponent() {
  return (
    <div>
      <p>Sample Component</p>
    </div>
  )
}
