// Sample page component
export default function HomePage() {
  return (
    <div>
      <h2>Home Page</h2>
    </div>
  )
}
