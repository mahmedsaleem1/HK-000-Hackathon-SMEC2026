const users = new Map();
const friendConnections = new Map();

module.exports = {
  users,
  friendConnections
};
