// Utility functions
